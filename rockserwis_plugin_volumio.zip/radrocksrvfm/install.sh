#!/bin/bash

echo "Installing radio Rockserwis FM Dependencies"

#requred to end the plugin install
echo "plugininstallend"
